<?php
  require_once('vendor/autoload.php');
  \Stripe\Stripe::setApiKey('sk_test_CcG5lG0S9hQRlcTKgv89mzaz00RVA9izTo');

  $POST = filter_var_array($_POST, FILTER_SANITIZE_STRING);

  $name = $POST['name'];
  $email = $POST['email'];
  $token = $POST['stripeToken'];

  // Create Customer In Stripe
  $customer = \Stripe\Customer::create(array(
    "name" => $name,
    "email" => $email,
    "source" => $token
  ));

  // Charge Customer
  $charge = \Stripe\Charge::create(array(
    "amount" => 500,
    "currency" => "jpy",
    "description" => "激レア変身ベルト",
    "customer" => $customer->id
  ));

  // Customer Data
  $customerData = [
    'id' => $charge->customer,
    'name' => $name,
    'email' => $email
  ];

  // Transaction Data
  $transactionData = [
    'id' => $charge->id,
    'customer_id' => $charge->customer,
    'product' => $charge->description,
    'amount' => $charge->amount,
    'currency' => $charge->currency,
    'status' => $charge->status,
  ];

  // Redirect to success
  header('Location: success.php?tid='.$charge->id.'&product='.$charge->description.'&amount='.$charge->amount);
